﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.UI;

[assembly: log4net.Config.XmlConfigurator(Watch =true)]

namespace ConsoleUI
{
    class Program
    {
        private static readonly log4net.ILog log = LogHelper.GetLogger();//log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        static void Main(string[] args)
        {
            //log.Error("Сообщение об ошибке");
            log.Debug("developer debug");
            //log.Info("maintenance: wster pump turned on");
            //log.Warn("maintenance the water pump is getting hot");

            //var i = 0;

            //try
            //{
            //    var x = 10 / i;
            //}

            //catch (DivideByZeroException ex)
            //{
            //    log.Error("Сообщение об ошибке", ex);
            //}

            /*log.Fatal("water pump exloded");*/ //1 02 55

            Console.ReadLine();
        }
    }
}
